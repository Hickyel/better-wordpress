<?php
echo "Silence is golden.";
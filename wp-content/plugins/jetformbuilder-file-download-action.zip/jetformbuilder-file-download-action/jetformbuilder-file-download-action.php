<?php
/**
 * Plugin Name: JetFormBuilder - File Download Action
 * Plugin URI:  https://example.com/
 * Description: Ajoute une action de post-submit à JetFormBuilder pour rediriger vers un fichier à télécharger.
 * Version:     1.0
 * Author:      Votre Nom
 * Author URI:  https://example.com/
 * Text Domain: jetformbuilder-file-download
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Sécurité
}

// Vérifier si JetFormBuilder est actif (la classe de base de l'action existe)
if ( ! class_exists( 'Jet_Form_Builder_Post_Submit_Action' ) ) {
	return;
}

/**
 * Classe personnalisée pour l'action de téléchargement de fichier.
 */
class JBFD_File_Download_Action extends Jet_Form_Builder_Post_Submit_Action {

	/**
	 * Retourne le nom unique de l'action.
	 */
	public function get_name() {
		return 'file_download';
	}

	/**
	 * Label affiché dans l'interface de JetFormBuilder.
	 */
	public function get_label() {
		return __( 'File Download', 'jetformbuilder-file-download' );
	}

	/**
	 * Définition des réglages spécifiques à cette action.
	 */
	public function get_settings() {
		return array(
			'file_url' => array(
				'type'    => 'text',
				'label'   => __( 'File URL', 'jetformbuilder-file-download' ),
				'default' => '',
			),
		);
	}

	/**
	 * Exécution de l'action lors de la soumission du formulaire.
	 *
	 * @param int   $form_id   L'ID du formulaire.
	 * @param array $form_data Les données soumises.
	 * @param object $response  L'objet réponse de JetFormBuilder.
	 */
	public function run( $form_id, $form_data, $response ) {
		// Récupération de l'URL du fichier défini dans les réglages de l'action
		$file_url = ! empty( $this->settings['file_url'] ) ? $this->settings['file_url'] : '';

		if ( ! $file_url ) {
			// Rien à faire si aucun fichier n'est défini
			return;
		}

		/**
		 * Ici, nous utilisons la méthode add_redirect() de la réponse pour rediriger l'utilisateur.
		 * Si le formulaire est soumis via AJAX, cette redirection devra être traitée en front-end.
		 * Vous pouvez adapter cette logique pour insérer du JavaScript ou toute autre méthode
		 * afin de forcer le téléchargement selon votre implémentation.
		 */
		$response->add_redirect( $file_url );
	}
}

/**
 * Enregistrement de l'action personnalisée dans JetFormBuilder.
 */
function jbfd_register_file_download_action() {
	if ( class_exists( 'Jet_Form_Builder_Post_Submit_Actions_Manager' ) ) {
		Jet_Form_Builder_Post_Submit_Actions_Manager::instance()->register_action( new JBFD_File_Download_Action() );
	}
}
add_action( 'jet-form-builder/init', 'jbfd_register_file_download_action' );
